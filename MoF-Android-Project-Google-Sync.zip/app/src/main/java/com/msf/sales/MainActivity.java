package com.msf.sales;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.PermissionRequest;
import android.webkit.JavascriptInterface;
import android.util.Base64;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int GOOGLE_SIGN_IN = 1002;
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        auth = FirebaseAuth.getInstance(); db = FirebaseFirestore.getInstance();
        webView = new WebView(this);
        WebSettings settings = webView.getSettings(); settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true); settings.setAllowFileAccess(true); settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AppBridge(), "MoFAndroid");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null); fileCallback = callback;
                try { startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST); return true; }
                catch (Exception e) { fileCallback = null; return false; }
            }
            @Override public void onPermissionRequest(PermissionRequest request) { runOnUiThread(() -> request.grant(request.getResources())); }
        });
        setContentView(webView); webView.loadUrl("file:///android_asset/index.html");
    }
    private void js(String script) { runOnUiThread(() -> { if(webView!=null) webView.evaluateJavascript(script,null); }); }
    private void message(String fn, String value) { String b=Base64.encodeToString(value.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP); js("window."+fn+" && window."+fn+"(atob('"+b+"'))"); }
    private class AppBridge {
        @JavascriptInterface public void signIn() {
            runOnUiThread(() -> {
                try {
                    String clientId=getString(getResources().getIdentifier("default_web_client_id","string",getPackageName()));
                    GoogleSignInOptions gso=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(clientId).requestEmail().build();
                    startActivityForResult(GoogleSignIn.getClient(MainActivity.this,gso).getSignInIntent(),GOOGLE_SIGN_IN);
                } catch(Exception e) { message("mofAuthResult","تعذر بدء تسجيل الدخول: "+e.getMessage()); }
            });
        }
        @JavascriptInterface public void sync(String json) {
            if(auth.getCurrentUser()==null){message("mofSyncResult","يرجى تسجيل الدخول أولاً");return;}
            if(json==null || json.getBytes(StandardCharsets.UTF_8).length>850000){message("mofSyncResult","حجم البيانات كبير للمزامنة؛ قلّل حجم الصور");return;}
            String uid=auth.getCurrentUser().getUid();
            db.collection("users").document(uid).collection("products").document("current").set(java.util.Collections.singletonMap("payload",json))
              .addOnSuccessListener(v->message("mofSyncResult","تمت المزامنة مع حساب Google"))
              .addOnFailureListener(e->message("mofSyncResult","فشلت المزامنة: "+e.getMessage()));
        }
        @JavascriptInterface public void restore() {
            if(auth.getCurrentUser()==null){message("mofSyncResult","يرجى تسجيل الدخول أولاً");return;}
            db.collection("users").document(auth.getCurrentUser().getUid()).collection("products").document("current").get()
              .addOnSuccessListener(d->{ if(d.exists() && d.getString("payload")!=null) message("mofCloudData",d.getString("payload")); else message("mofSyncResult","لا توجد نسخة سحابية بعد"); })
              .addOnFailureListener(e->message("mofSyncResult","تعذر جلب البيانات: "+e.getMessage()));
        }
        @JavascriptInterface public String account(){return auth.getCurrentUser()==null?"":auth.getCurrentUser().getEmail();}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_CHOOSER_REQUEST && fileCallback!=null){Uri[] r=null;if(resultCode==RESULT_OK&&data!=null){if(data.getClipData()!=null){int n=data.getClipData().getItemCount();r=new Uri[n];for(int i=0;i<n;i++)r[i]=data.getClipData().getItemAt(i).getUri();}else if(data.getData()!=null)r=new Uri[]{data.getData()};}fileCallback.onReceiveValue(r);fileCallback=null;}
        if(requestCode==GOOGLE_SIGN_IN){try{String token=GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException.class).getIdToken();auth.signInWithCredential(GoogleAuthProvider.getCredential(token,null)).addOnSuccessListener(a->{message("mofAuthResult","تم تسجيل الدخول: "+a.getUser().getEmail());new AppBridge().restore();}).addOnFailureListener(e->message("mofAuthResult","فشل تسجيل الدخول: "+e.getMessage()));}catch(Exception e){message("mofAuthResult","لم يكتمل تسجيل الدخول: "+e.getMessage());}}
    }
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
