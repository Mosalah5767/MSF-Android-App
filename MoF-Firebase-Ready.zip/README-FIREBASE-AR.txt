ربط Mo.F Sales Assistant مع Firebase

ما الذي أضيف؟
- تسجيل الدخول بحساب Google باستخدام Firebase Authentication.
- حفظ كل منتج في مستند مستقل داخل Firestore تحت المسار users/{uid}/products.
- الاحتفاظ بنسخة محلية على الهاتف، والعمل محلياً عند انقطاع الإنترنت.
- جلب بيانات الحساب عند فتح التطبيق، مع سؤال المستخدم عند وجود بيانات على الهاتف وفي السحابة.
- مزامنة التغييرات إلى Firestore بعد توفر الاتصال.
- لم يتغير تصميم التطبيق الأسود والذهبي أو الأيقونة.

الخطوات المطلوبة قبل استخدام تسجيل الدخول:
1) ارفع هذا المشروع إلى GitHub وشغّل GitHub Actions.
2) افتح سجل البناء (Actions) وابحث عن خطوة Print Android debug SHA-1 for Firebase.
3) انسخ قيمة SHA1 من قسم Variant: debug ثم Config: debug.
4) في Firebase Console افتح Project settings ثم Your apps ثم تطبيق Android com.msf.sales، وأضف بصمة SHA-1.
5) نزّل google-services.json الجديد بعد إضافة البصمة، واستبدل الملف app/google-services.json داخل المشروع.
6) ارفع النسخة الجديدة إلى GitHub وشغّل البناء مرة أخرى.
7) ثبّت APK، وافتح الإعدادات داخل التطبيق، ثم اضغط ربط الحساب واختر حساب Google.

قواعد Firestore المطلوبة:
يسمح المسار التالي لكل مستخدم بالوصول إلى بياناته فقط:
match /users/{userId}/{document=**} {
  allow read, write: if request.auth != null && request.auth.uid == userId;
}

ملاحظات:
- يجب أن يكون Google provider مفعلاً في Firebase Authentication.
- ملف google-services.json الحالي يطابق package name، لكن ملف OAuth client يحتاج إلى بصمة SHA-1 المضافة حديثاً.
- مزامنة الصور تتم حالياً ضمن بيانات المنتج في Firestore؛ لكل مستند حد أقصى لحجم المستند من Firebase، لذلك إذا كانت صور منتج واحد كبيرة جداً قد تفشل مزامنته. لا تحذف النسخ المحلية واحتفظ بنسخة احتياطية.
- التخزين المحلي لا يعتمد على الإنترنت. Firestore يحتفظ بعمليات الكتابة غير المتصلة ويرسلها عند عودة الاتصال.
- لا يمكن اعتبار الربط ناجحاً إلا بعد إضافة SHA-1، تنزيل ملف الإعداد الجديد، تثبيت APK الناتج، وتجربة تسجيل الدخول والمزامنة.
