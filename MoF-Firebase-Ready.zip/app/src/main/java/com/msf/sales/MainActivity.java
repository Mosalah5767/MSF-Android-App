package com.msf.sales;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.PermissionRequest;
import android.webkit.JavascriptInterface;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;
import java.util.ArrayList;
import java.util.List;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.WriteBatch;
import com.google.firebase.firestore.QuerySnapshot;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int GOOGLE_SIGN_IN_REQUEST = 1002;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;

    public class AppStorage {
        private File dataFile() { return new File(getFilesDir(), "msf-products-v2.json"); }

        @JavascriptInterface
        public synchronized String loadData() {
            File file = dataFile();
            if (!file.exists()) return "";
            try (FileInputStream in = new FileInputStream(file)) {
                byte[] bytes = new byte[(int) file.length()];
                int offset = 0, count;
                while (offset < bytes.length && (count = in.read(bytes, offset, bytes.length - offset)) > 0) offset += count;
                return new String(bytes, 0, offset, StandardCharsets.UTF_8);
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public synchronized boolean saveData(String json) {
            if (json == null) return false;
            File target = dataFile();
            File temp = new File(getFilesDir(), "msf-products-v2.tmp");
            File backup = new File(getFilesDir(), "msf-products-v2.bak");
            try {
                if (temp.exists() && !temp.delete()) return false;
                try (FileOutputStream out = new FileOutputStream(temp)) {
                    out.write(json.getBytes(StandardCharsets.UTF_8)); out.flush(); out.getFD().sync();
                }
                if (backup.exists() && !backup.delete()) { temp.delete(); return false; }
                boolean hadTarget = target.exists();
                if (hadTarget && !target.renameTo(backup)) { temp.delete(); return false; }
                if (!temp.renameTo(target)) {
                    if (hadTarget) backup.renameTo(target);
                    temp.delete(); return false;
                }
                if (backup.exists()) backup.delete();
                if (firebaseAuth != null && firebaseAuth.getCurrentUser() != null) syncProductsToCloud(json);
                return true;
            } catch (Exception e) {
                if (!target.exists() && backup.exists()) backup.renameTo(target);
                if (temp.exists()) temp.delete();
                return false;
            }
        }

        @JavascriptInterface
        public void signInGoogle() {
            runOnUiThread(() -> beginGoogleSignIn());
        }

        @JavascriptInterface
        public void syncCloudData() {
            String local = loadData();
            if (local != null && !local.isEmpty()) syncProductsToCloud(local);
            else fetchProductsFromCloud();
        }

        @JavascriptInterface
        public void fetchCloudData() { fetchProductsFromCloud(); }

        @JavascriptInterface
        public String getAccountInfo() {
            if (firebaseAuth == null || firebaseAuth.getCurrentUser() == null) return "";
            JSONObject obj = new JSONObject();
            try { obj.put("email", firebaseAuth.getCurrentUser().getEmail()); obj.put("uid", firebaseAuth.getCurrentUser().getUid()); }
            catch (Exception ignored) {}
            return obj.toString();
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        firebaseAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AppStorage(), "MSFStorage");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                notifyAuthState();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try { startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST); return true; }
                catch (Exception e) { fileCallback = null; return false; }
            }
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void beginGoogleSignIn() {
        int webClientId = getResources().getIdentifier("default_web_client_id", "string", getPackageName());
        if (webClientId == 0) {
            js("window.onCloudError && window.onCloudError('لم يتم إعداد OAuth بعد. أضف بصمة SHA-1 في Firebase ثم نزّل google-services.json الجديد.');");
            return;
        }
        String clientId = getString(webClientId);
        GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail().requestIdToken(clientId).build();
        GoogleSignInClient client = GoogleSignIn.getClient(this, options);
        startActivityForResult(client.getSignInIntent(), GOOGLE_SIGN_IN_REQUEST);
    }

    private void notifyAuthState() {
        if (firebaseAuth != null && firebaseAuth.getCurrentUser() != null) {
            String email = JSONObject.quote(firebaseAuth.getCurrentUser().getEmail() == null ? "" : firebaseAuth.getCurrentUser().getEmail());
            String uid = JSONObject.quote(firebaseAuth.getCurrentUser().getUid());
            js("window.onFirebaseAuthChanged && window.onFirebaseAuthChanged(" + email + "," + uid + ");");
        } else js("window.onFirebaseAuthChanged && window.onFirebaseAuthChanged('', '');");
    }

    private void js(String script) { runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(script, null); }); }

    private void fetchProductsFromCloud() {
        if (firebaseAuth.getCurrentUser() == null) return;
        String uid = firebaseAuth.getCurrentUser().getUid();
        firestore.collection("users").document(uid).collection("products").get()
                .addOnSuccessListener(snapshot -> {
                    JSONArray all = new JSONArray();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        String payload = doc.getString("payload");
                        if (payload != null) try { all.put(new JSONObject(payload)); } catch (Exception ignored) {}
                    }
                    js("window.onCloudDataAvailable && window.onCloudDataAvailable(" + JSONObject.quote(all.toString()) + ");");
                })
                .addOnFailureListener(e -> js("window.onCloudError && window.onCloudError('تعذر قراءة البيانات السحابية. تحقق من الإنترنت وقواعد Firestore.');"));
    }

    private void syncProductsToCloud(String json) {
        if (firebaseAuth == null || firebaseAuth.getCurrentUser() == null || json == null) return;
        final JSONArray products;
        try { products = new JSONArray(json); }
        catch (Exception e) { js("window.onCloudError && window.onCloudError('صيغة بيانات المنتجات غير صالحة للمزامنة.');"); return; }
        String uid = firebaseAuth.getCurrentUser().getUid();
        com.google.firebase.firestore.CollectionReference ref = firestore.collection("users").document(uid).collection("products");
        ref.get().addOnSuccessListener(snapshot -> {
            Set<String> wanted = new HashSet<>();
            WriteBatch batch = firestore.batch(); int writes = 0;
            List<Task<Void>> commits = new ArrayList<>();
            for (int i = 0; i < products.length(); i++) {
                JSONObject product = products.optJSONObject(i); if (product == null) continue;
                String id = product.optString("id", "item-" + i);
                if (id.isEmpty()) id = "item-" + i;
                String docId = Base64.encodeToString(id.getBytes(StandardCharsets.UTF_8), Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
                wanted.add(docId);
                batch.set(ref.document(docId), java.util.Collections.singletonMap("payload", product.toString()));
                writes++;
                if (writes == 400) { commits.add(batch.commit()); batch = firestore.batch(); writes = 0; }
            }
            for (DocumentSnapshot old : snapshot.getDocuments()) {
                if (!wanted.contains(old.getId())) {
                    batch.delete(old.getReference()); writes++;
                    if (writes == 400) { commits.add(batch.commit()); batch = firestore.batch(); writes = 0; }
                }
            }
            if (writes > 0) commits.add(batch.commit());
            if (commits.isEmpty()) js("window.onCloudSyncComplete && window.onCloudSyncComplete();");
            else Tasks.whenAll(commits).addOnSuccessListener(v -> js("window.onCloudSyncComplete && window.onCloudSyncComplete();"))
                    .addOnFailureListener(e -> js("window.onCloudError && window.onCloudError('تعذرت مزامنة المنتجات. قد تكون إحدى الصور أو البيانات كبيرة جداً.');"));
        }).addOnFailureListener(e -> js("window.onCloudError && window.onCloudError('تعذر الاتصال بقاعدة البيانات السحابية.');"));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GOOGLE_SIGN_IN_REQUEST) {
            try {
                GoogleSignInAccount account = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException.class);
                AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
                firebaseAuth.signInWithCredential(credential).addOnSuccessListener(result -> {
                    notifyAuthState();
                }).addOnFailureListener(e -> js("window.onCloudError && window.onCloudError('فشل تسجيل الدخول إلى Firebase. تحقق من إعداد Google.');"));
            } catch (Exception e) { js("window.onCloudError && window.onCloudError('تم إلغاء تسجيل الدخول أو تعذر إكماله.');"); }
        }
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount(); results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) results = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(results); fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
